#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 23 13:58:10 2018

@author: brendan
"""

from application import app
app.run(debug=False)